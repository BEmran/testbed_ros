// USB4.h : USB4 header file.

#ifndef __USB4_H__
#define __USB4_H__



typedef int BOOL;
#define TRUE  1
#define FALSE 0



/*************************************************************************
|    Definitions                                                         |
*************************************************************************/

#define MAX_ERROR_MSG_LENGTH        512
#define MAX_INC_COUNTS              0x1000000
#define FAILURE                     FALSE       // must be zero
#define SUCCESS                     TRUE
#define USB4_SUCCESS                0
#define USB4_MAX_ENCODERS           4       // max number of encoders per device.
#define USB4_MAX_DEVICES            32      // max devices on USB bus
#define USB4_MAX_ADDRESSES          32      // address can be any valid single byte value
#define USB4_MAX_ADC_CHANNELS       4       // max number of a/d channels.
#define USB4_FIFO_MAX_COUNT         196607  // max number of ChannelBufferRecords in FIFO.
#define USB4_MAX_INPUT_TRIGGERS     8       // max number of input trigger channels.


//****** Error Codes ***************************/
#define DEVICE_NOT_OPEN                 -1
#define FAILED_TO_AQUIRE_MUTEX          -2
#define FAILED_TO_DOWNLOAD_FIRMWARE     -3
#define FATAL_ERROR                     -4
#define FIFO_BUFFER_EMPTY               -5
#define INVALID_A2D_CHANNEL             -6
#define INVALID_COUNTER_MODE            -7
#define INVALID_D2A_CHANNEL             -8
#define INVALID_D2A_MODE                -9
#define INVALID_DEVICE_NUMBER           -10
#define INVALID_ENCODER_NUMBER          -11
#define INVALID_MODULE_NUMBER           -12
#define INVALID_PARAMETER               -13
#define INVALID_QUADRATURE_MODE         -14
#define INVALID_REGISTER_NUMBER         -15
#define INVALID_SIGNAL_LENGTH_CODE      -16
#define MODULE_NUMBER_ALREADY_ASSIGNED  -17
#define MODULE_NUMBER_NOT_FOUND         -18
#define NO_AVAILABLE_MODULE_ADDRESSES   -19
#define USB4_INVALID_D2A_VALUE          -20
#define NO_DEVICES_FOUND                -32
#define OLD_FIRMWARE_DETECTED           -33
#define INSUFFICIENT_MEMORY_AVAILABLE   -34


//****** REGISTERS *****************************/

// Encoders                                   #0    #1   #2  #3
#define PRESET_REGISTER                        0  // 8   16  48
#define OUTPUT_LATCH_REGISTER                  1  // 9   17  49
#define MATCH_REGISTER                         2  // 10  18  50  
#define CONTROL_REGISTER                       3  // 11  19  51
#define STATUS_REGISTER                        4  // 12  20  52
#define COUNTER_REGISTER                       5  // 13  21  53  Renamed from RESET_CHANNEL_REGISTER
#define RESET_CHANNEL_REGISTER                 5  // Not currently used.
#define TRANSFER_PRESET_REGISTER               6  // 14  22  54


// Control and timestamp

// CMD register
// Bit          R/W?    Description
//  31 to 24    RO      R: ROM version
//  23 to 7     -       Reserved
// 
//  6           R/W     0: 48MHz Time Stamp Counter enabled
//                      1: clear and stop Time Stamp Counter
//  5           R/W     Write '0' then '1' to transfer Time Stamp Counter to Time Stamp Latch
//  4           R/W     Write '0' then '1' to transfer Time Stamp Counter to Time Stamp Latch, 
//                      transfer all encoder counters with "captured enabled" to Output latch and 
//                      force a pulse on the "Combined Trigger" signal
//  3 to 0      -       Reserved
//
// Bits 31 to 24 is the ROM version currently 0x01
// Bits 23 to 8  is the ROM signature currently 0x75d1 (looks like "USDI")
// The rest of the bits are the same as before.
//
#define CMD_REGISTER                           7


#define TIMESTAMP_OUTPUT_LATCH_REGISTER        15
#define TIMESTAMP_REGISTER                     23


// Event-based trigger
#define INPUT_TRIGGER_CONTROL_REGISTER         27
#define INPUT_TRIGGER_STATUS_REGISTER          28


// Time-based trigger configuration
#define SAMPLING_RATE_MULTIPLIER_REGISTER      30
#define SAMPLING_RATE_COUNTER_REGISTER         31
#define SAMPLES_TO_COLLECT_REGISTER            43
#define SAMPLES_REMAINING_TO_COLLECT_REGISTER  44
#define AQUISITION_CONTROL_REGISTER            45



// Time-based trigger source
// Using digital input port.
#define INPUT_TRIGGER1_SETUP_REGISTER          41
#define INPUT_TRIGGER2_SETUP_REGISTER          42
// Using ADCs
#define ADC01_TRIGGER_CONTROL_REGISTER         24
#define ADC23_TRIGGER_CONTROL_REGISTER         25
// Using PWMs
#define USB_PWM0_TRIGGER_CONTROL_REGISTER      32
#define USB_PWM1_TRIGGER_CONTROL_REGISTER      33
#define USB_PWM2_TRIGGER_CONTROL_REGISTER      34
#define USB_PWM3_TRIGGER_CONTROL_REGISTER      35


// Digital I/O
#define INPUT_PORT_REGISTER                    40
#define OUTPUT_PORT_REGISTER                   46
#define OUTPUT_PORT_SETUP_REGISTER             47
#define USB4_ENCODER3_BASE                     48


// FIFO
#define FIFO_ON_OFF_REGISTER                   37
#define FIFO_STATUS_CONTROL_REGISTER           38
#define FIFO_BUFFER_COUNT                      39


// ADC-DAC
#define USB4_A2D_BASE_REGISTER                 55
#define USB4_A2D_CHANNEL0_REGISTER             55
#define USB4_A2D_CHANNEL1_REGISTER             56
#define USB4_A2D_CHANNEL2_REGISTER             57
#define USB4_A2D_CHANNEL3_REGISTER             58
#define USB4_D2A_CONTROL_REGISTER              59


// PWM Measurement Control
#define ENCODER_TYPE_REGISTER                  26
#define USB4_PW0_REGISTER                      60
#define USB4_PER0_REGISTER                     61
#define USB4_PW1_REGISTER                      62
#define USB4_PER1_REGISTER                     63
#define USB4_PW2_REGISTER                      64
#define USB4_PER2_REGISTER                     65
#define USB4_PW3_REGISTER                      66
#define USB4_PER3_REGISTER                     67


//****** Status Register Bits ******************/       // bit  6-0 reserved
#define STATUS_BIT_LATCHED_ZERO_DETECTED    0x00000080  // bit  7
#define STATUS_BIT_LATCHED_MATCH_DETECTED   0x00000100  // bit  8
#define STATUS_BIT_LATCHED_CARRY_DETECTED   0x00000200  // bit  9
#define STATUS_BIT_LATCHED_BORROW_DETECTED  0x00000400  // bit 10
#define STATUS_BIT_LATCHED_INDEX_DETECTED   0x00000800  // bit 11
#define STATUS_BIT_LATCHED_ADVANCE_DETECTED 0x00001000  // bit 12
#define STATUS_BIT_LATCHED_RETARD_DETECTED  0x00002000  // bit 13
#define STATUS_BIT_ZERO_DETECTED            0x00004000  // bit 14
#define STATUS_BIT_MATCH_DETECTED           0x00008000  // bit 15
#define STATUS_BIT_CARRY_DETECTED           0x00010000  // bit 16
#define STATUS_BIT_BORROW_DETECTED          0x00020000  // bit 17
#define STATUS_BIT_INDEX_DETECTED           0x00040000  // bit 18
#define STATUS_BIT_ADVANCE_DETECTED         0x00080000  // bit 19
#define STATUS_BIT_RETARD_DETECTED          0x00100000  // bit 20
// bit 22-21 reserved
#define STATUS_BIT_LAST_DIRECTION_INDICATOR 0x08000000  // bit 23           
// bit 31-24 reserved

//****** Control Register Bits ******************/          // bit  6-0
#define CONTROL_BIT_INDEX_ENABLE_ON_MATCH       0x00000010  // bit  4
#define CONTROL_BIT_TRIGGER_ON_ZERO             0x00000080  // bit  7
#define CONTROL_BIT_TRIGGER_ON_MATCH            0x00000100  // bit  8
#define CONTROL_BIT_TRIGGER_ON_ROLLOVER         0x00000200  // bit  9
#define CONTROL_BIT_TRIGGER_ON_ROLLUNDER        0x00000400  // bit 10
#define CONTROL_BIT_TRIGGER_ON_INDEX            0x00000800  // bit 11
#define CONTROL_BIT_TRIGGER_ON_INCREASE         0x00001000  // bit 12
#define CONTROL_BIT_TRIGGER_ON_DECREASE         0x00002000  // bit 13
#define CONTROL_BITS_MULTIPLIER                 0x0000C000  // bits 14 & 15
#define CONTROL_BITS_COUNTER_MODE               0x00030000  // bits 16 & 17
#define CONTROL_BIT_COUNTER_ENABLE              0x00040000  // bit 18
#define CONTROL_BIT_COUNT_DIRECTION             0x00080000  // bit 19
#define CONTROL_BIT_INDEX_ENABLE                0x00100000  // bit 20
#define CONTROL_BIT_INVERT_INDEX                0x00200000  // bit 21
#define CONTROL_BIT_COUNTER_RESET_OR_PRESET     0x00400000  // bit 22
#define CONTROL_BIT_ENABLE_CAPTURE              0x00800000  // bit 23
// bit 31-24 reserved

//******* Input Port Register Bits ***************/
#define INPUT_PORT_ESTOP                        0x00000100  // bit 8

//******* Output Port Configuration Bits ***************/
#define INVERT_OUTPUT_POLARITY                  0x00000020  // bit 5


#ifdef __cplusplus 
extern "C"{ 
#endif 

    typedef struct 
    {
        unsigned char Header[6];
        unsigned char Input;
        unsigned char EStop;
        unsigned int  Time;
        unsigned int  Count[4];
        unsigned char Status[4];
        unsigned short ADC[4];
    } USB4_FIFOBufferRecord;

    int USB4_CaptureTimeAndCounts(short deviceNumber, unsigned int* counts, unsigned int* timeStamp);
    int USB4_ClearCapturedStatus(short deviceNumber, short encoder);
    int USB4_ClearDigitalInputTriggerStatus(short deviceNumber);
    int USB4_ClearFIFOBuffer(short deviceNumber);
    int USB4_DeviceCount(void);
    int USB4_DisableFIFOBuffer(short deviceNumber);
    int USB4_EnableFIFOBuffer(short deviceNumber);
    int USB4_GetA2D(short deviceNumber, short a2dChannel, unsigned short* a2dValue);
    int USB4_GetA2DSamplingFrequency(short deviceNumber, unsigned short* value);
    int USB4_GetCaptureEnabled(short deviceNumber, short encoder, BOOL* isEnabled);
    int USB4_GetControlMode(short deviceNumber, short encoder, unsigned int* controlMode);
    int USB4_GetCount(short deviceNumber, short encoder, unsigned int* count);
    int USB4_GetCounterMode(short deviceNumber, short encoder, short* counterMode);
    int USB4_GetDeviceNo(short moduleAddress, short* deviceNumber);
    int USB4_GetDigitalInputTriggerConfig(short deviceNumber, BOOL* enableTrigger, BOOL* triggerOnRisingEdge);
    int USB4_GetDigitalInputTriggerStatus(short deviceNumber, BOOL* status);
    int USB4_GetDriverBuildNumber(short deviceNumber, unsigned char* version);
    int USB4_GetCounterEnabled(short deviceNumber, short encoder, BOOL* isEnabled);
    int USB4_GetEnableIndex(short deviceNumber, short encoder, BOOL* isEnabled);
    int USB4_GetEnableIndexOnMatch(short deviceNumber, short encoder, BOOL* value);
    int USB4_GetEStopBit(short deviceNumber, unsigned char* stopBit);
    int USB4_GetFactoryInfo(short deviceNumber, unsigned short* model, 
                            unsigned short* version, unsigned int* serialNumber, 
                            unsigned char* month, unsigned char* day, unsigned short* year);
    int USB4_GetFIFOBufferCount(short deviceNumber, unsigned int* count);
    int USB4_GetForward(short deviceNumber, short encoder, BOOL* value);
    int USB4_GetInvertIndex(short deviceNumber, short encoder, BOOL* value);
    int USB4_GetInvertOutput(short deviceNumber, BOOL* value);
    int USB4_GetMatch(short deviceNumber, short encoder, unsigned int* match);
    int USB4_GetModuleAddress(short deviceNumber, unsigned char* moduleAddress);
    int USB4_GetMultiplier(short deviceNumber, short encoder, short* multiplier);
    int USB4_GetOutputPortConfig(short deviceNumber, BOOL* triggerOutSignalDrivesOutputPin, 
                                 unsigned char* triggerSignalLengthCode);
    int USB4_GetPresetOnIndex(short deviceNumber, short encoder, BOOL* value);
    int USB4_GetPresetValue(short deviceNumber, short encoder, unsigned int* value);
    int USB4_GetPWM(short deviceNumber, short pwmChannel, unsigned int* pulseWidth, unsigned int* pulsePeriod);
    int USB4_GetPWMConfig(short deviceNumber, unsigned char* divisor, unsigned char* captureToFIFOFlags);
    int USB4_GetROM_ID(short deviceNumber, unsigned char* romId);
    int USB4_GetRPM(short deviceNumber, short encoder, float* rpm);
    int USB4_GetSamplesRemaining(short deviceNumber, unsigned int* samplesRemaining);
    int USB4_GetSamplesToCollect(short deviceNumber, unsigned int* samplesToCollect);
    int USB4_GetSamplingRateCounter(short deviceNumber, unsigned int* count);
    int USB4_GetSamplingRateMultiplier(short deviceNumber, unsigned int* multiplier);
    int USB4_GetStatus(short deviceNumber, short encoder, unsigned int* status);
    int USB4_GetStatusEx(short deviceNumber, short encoder, BOOL* decreaseDetected, BOOL* increaseDetected, 
                         BOOL* indexDetected, BOOL* rollunderDetected, BOOL* rolloverDetected, 
                         BOOL* matchDetected, BOOL* zeroDetected);
    int USB4_GetTimeBasedLogSettings(short deviceNumber, 
                                     unsigned char* inputTrigger1Array, unsigned char* inputTrig1And,
                                     unsigned char* inputTrigger2Array, unsigned char* inputTrig2And,
                                     unsigned char* adcTrigger, unsigned short* adcThreshold,
                                     unsigned char* pwmTrigger, unsigned int* pwmThreshold,
                                     unsigned char* encoderChannels, unsigned int* numberOfSamples);
    int USB4_GetTimeStamp(short deviceNumber, unsigned int* timeStamp);
    int USB4_GetTriggerOnDecrease(short deviceNumber, short encoder, BOOL* value);
    int USB4_GetTriggerOnIncrease(short deviceNumber, short encoder, BOOL* value);
    int USB4_GetTriggerOnIndex(short deviceNumber, short encoder, BOOL* value);
    int USB4_GetTriggerOnMatch(short deviceNumber, short encoder, BOOL* value);
    int USB4_GetTriggerOnRollover(short deviceNumber, short encoder, BOOL* value);
    int USB4_GetTriggerOnRollunder(short deviceNumber, short encoder, BOOL* value);
    int USB4_GetTriggerOnZero(short deviceNumber, short encoder, BOOL* value);
    int USB4_GetVersion(short deviceNumber, unsigned short* version);
    int USB4_Initialize(short* deviceCount);
    BOOL USB4_IsFIFOBufferEmpty(short deviceNumber, int* isEmpty);
    BOOL USB4_IsFIFOBufferFull(short deviceNumber, int* isFull);
    int USB4_PresetCount(short deviceNumber, short encoder);
    int USB4_ReadFIFOBuffer(short deviceNumber, int* size, unsigned int* time, 
                            unsigned int* count0, unsigned int* count1, unsigned int* count2, unsigned int* count3, 
                            unsigned char* status0, unsigned char* status1, unsigned char* status2, unsigned char* status3, 
                            unsigned char* input, unsigned char* eStop, 
                            unsigned int* adc0, unsigned int* adc1, unsigned int* adc2, unsigned int* adc3, 
                            unsigned int readTimeout);
    int USB4_ReadFIFOBufferStruct(short deviceNumber, int* recordsToRead, 
                                  USB4_FIFOBufferRecord* bufferRecords, unsigned int readTimeout);
    int USB4_ReadInputPortRegister(short deviceNumber, unsigned char* value);
    int USB4_ReadOutputLatch(short deviceNumber, short encoder, unsigned int* value);
    int USB4_ReadOutputPortRegister(short deviceNumber, unsigned char* value);
    int USB4_ReadRegister(short deviceNumber, short iRegister, unsigned int *value);
    int USB4_ReadSavedParameters(short deviceNumber);
    int USB4_ReadTimeAndCounts(short deviceNumber, unsigned int* counts, unsigned int* timeStamp);
    int USB4_ReadTimeStamp(short deviceNumber, unsigned int *value);
    int USB4_ReadUnlatchedTimeAndCounts(short deviceNumber, unsigned int* counts, unsigned int* timeStamp);
    int USB4_ReadUserEEPROM(short deviceNumber, unsigned char startAddress, 
                            unsigned char bytesToRead, unsigned char *data);
    int USB4_ResetCount(short deviceNumber, short encoder);
    int USB4_ResetTimeStamp(short deviceNumber);
    int USB4_RestoreFactoryParameters(short deviceNumber);
    int USB4_SaveParameters(short deviceNumber);
    int USB4_SetA2DSamplingFrequency(short deviceNumber, unsigned short samplingFrequency);
    int USB4_SetCaptureEnabled(short deviceNumber, short encoder, BOOL value);
    int USB4_SetControlMode(short deviceNumber, short encoder, unsigned int mode);
    int USB4_SetCount(short deviceNumber, short encoder, unsigned int count);
    int USB4_SetCounterMode(short deviceNumber, short encoder, short coutnerMode);
    int USB4_SetD2A(short deviceNumber, short channel, unsigned short value, BOOL updateD2AChannelsNow);
    int USB4_SetD2AControlMode(short deviceNumber, unsigned char mode);
    int USB4_SetDigitalInputTriggerConfig(short deviceNumber, BOOL* enableTrigger, BOOL* triggerOnRisingEdge);
    int USB4_SetCounterEnabled(short deviceNumber, short encoder, BOOL enabled);
    int USB4_SetEnableIndex(short deviceNumber, short encoder, BOOL value);
    int USB4_SetEnableIndexOnMatch(short deviceNumber, short encoder, BOOL value);
    int USB4_SetEStopBit(short deviceNumber, unsigned char value);
    int USB4_SetForward(short deviceNumber, short encoder, BOOL value);
    int USB4_SetInvertIndex(short deviceNumber, short encoder, BOOL value);
    int USB4_SetInvertOutput(short deviceNumber, BOOL value);
    int USB4_SetMatch(short deviceNumber, short encoder, unsigned int match);
    int USB4_SetModuleAddress(short deviceNumber, unsigned char moduleAddress);
    int USB4_SetMultiplier(short deviceNumber, short encoder, short multiplier);
    int USB4_SetOutputPortConfig(short deviceNumber, BOOL* triggerOutSignalDrivesOutputPin, 
                                 unsigned char triggerSignalLengthCode);
    int USB4_SetPresetOnIndex(short deviceNumber, short encoder, BOOL value);
    int USB4_SetPresetValue(short deviceNumber, short encoder, unsigned int value);
    int USB4_SetPWMConfig(short deviceNumber, unsigned char divisor, unsigned char captureToFIFOFlags);
    int USB4_SetSamplesToCollect(short deviceNumber, unsigned int value);
    int USB4_SetSamplingRateMultiplier(short deviceNumber, unsigned int value);
    int USB4_SetTimeBasedLogSettings(short deviceNumber, 
                                     unsigned char* inputTrigger1Array, unsigned char inputTrig1And, 
                                     unsigned char* inputTrigger2Array, unsigned char inputTrig2And, 
                                     unsigned char* adcTrigger, unsigned short* adcThreshold, 
                                     unsigned char* pwmTrigger, unsigned int* pwmThreshold, 
                                     unsigned char encoderChannels, unsigned int numberOfSamples);
    int USB4_SetTriggerOnDecrease(short deviceNumber, short encoder, BOOL value);
    int USB4_SetTriggerOnIncrease(short deviceNumber, short encoder, BOOL value);
    int USB4_SetTriggerOnIndex(short deviceNumber, short encoder, BOOL value);
    int USB4_SetTriggerOnMatch(short deviceNumber, short encoder, BOOL value);
    int USB4_SetTriggerOnRollover(short deviceNumber, short encoder, BOOL value);
    int USB4_SetTriggerOnRollunder(short deviceNumber, short encoder, BOOL value);
    int USB4_SetTriggerOnZero(short deviceNumber, short encoder, BOOL value);
    void USB4_Shutdown(void);
    int USB4_StartAcquisition(short deviceNumber);
    int USB4_StopAcquisition(short deviceNumber);
    int USB4_TriggerSoftwareCapture(short deviceNumber);
    int USB4_WriteOutputPortRegister(short deviceNumber, unsigned char value);
    int USB4_WriteRegister(short deviceNumber, short iRegister, unsigned int value);
    int USB4_WriteUserEEPROM(short deviceNumber, unsigned char startAddress, 
                             unsigned char bytesToWrite, unsigned char* data);


#ifdef __cplusplus 
} 
#endif 


#endif

